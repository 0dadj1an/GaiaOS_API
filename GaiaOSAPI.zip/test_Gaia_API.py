#!/bin/python

'''
This code is for Check Point R80.10 GaiaOS API testing
@author: ivohrbacek@gmail.com and LAURA
'''


from pprint import pprint
import json
from connector import Connector

def push_data(data, connect):

    """
    go through JSON data and push them to API
    """
    
    # get dictionaries of all static routes and push them via API
    print ("Adding static routes")
    for item in data['static_routes']:
        pprint(item)
        connect.send_cmd('set-static-route', item)
        print("")

    # default route    
    print ("Adding default route")
    for item in data['default_gw']:
        pprint(item)
        connect.send_cmd('set-default-gw', item)
        print("")
        

    # get dictionaries of all vlans and push them via API
    print ("Adding vlans..")
    for item in data['vlans']:
        pprint(item)
        connect.send_cmd('/set-interface/add-vlan', item)
        print("")

    # get dictionaries of all interfaces and push them via API
    print ("Adding interfaces..")
    for item in data['interfaces']:
        pprint(item)
        connect.send_cmd('set-interface', item)
        print("")

    #set dns servers
    print ("Adding dns..")
    for item in data['dns']:
        pprint(item)
        connect.send_cmd('set-dns', item)
        print("")
    
    #set hostname
    print ("Adding hostname..")
    for item in data['name']:
        pprint(item)
        connect.send_cmd('set-hostname', item)
        print("")

    #set NTP
    print ("Adding NTP..")
    for item in data['ntp']:
        pprint(item)
        connect.send_cmd('set-ntp/primary', item)
        print("")

    # NTP state
    print ("set NTP state..")
    for item in data['ntp_state']:
        pprint(item)
        connect.send_cmd('set-ntp/state', item)
        print("")
    





def show_data(connect):
    """
    show commands to verify results of changes or show commands
    """
    # payloads
    payload={}
    payload_vlan={"interface":"eth1"}
    paylod_interface={"interface": "eth1.100"}

    print("")
    print ("Showing data from firewall..")
    print("")


    print ("INTERFACES")
    connect.send_cmd('show-interfaces', payload)
    print("")
    print ("ROUTES")
    connect.send_cmd('show-routes', payload)
    print("")
    print ("VLANS")
    connect.send_cmd('show-interface/vlans', payload_vlan)
    print("")
    print ("CPVIEW")
    connect.send_cmd('cpview/overview', payload)
    print("")
    print ("CPVIEW_NET_TRAFFIC")
    connect.send_cmd('cpview/network-traffic', payload)
    print("")
    print ("CPVIEW_overview")
    connect.send_cmd('cpview/overview', payload)
    print("")
    print ("DNS")
    connect.send_cmd('show-dns', payload)
    print("")
    print ("NAME")
    connect.send_cmd('show-hostname', payload)
    print("")
    print ("CPHAPROB-A IF")
    connect.send_cmd('cphaprob/a-if', payload)
    print("")
    print ("SHOW INSTALLER PACKAGES")
    connect.send_cmd('show-installer/packages/recommended', payload)
    print("")
    print ("SHOW ASSETS")
    connect.send_cmd('show-asset', payload)
    print("")
    print ("SHOW BANNER")
    connect.send_cmd('show-message/banner', payload)
    print("")
    print ("CPHAPROB LIST")
    connect.send_cmd('cphaprob/list', payload)
    print("")
    print ("CPSTAT OS")
    connect.send_cmd('cpstat/os', payload)
    print("")
    print ("SHOW_HOSTNAME")
    connect.send_cmd('show-hostname', payload)
    print("")
    print ("SHOW_INTERFACE")
    connect.send_cmd('show-interface', paylod_interface)
    print("")
    print ("SHOW_NTP_CURRENT")
    connect.send_cmd('show-ntp/current', payload)
    print("")
    print ("SHOW_NTP_SERVERS")
    connect.send_cmd('show-ntp/servers', payload)
    print("")
    print ("SHOW_NTP_STATE")
    connect.send_cmd('show-ntp/state', payload)
    print("")


    
   
    
    
    



def main():

    """
    main method, definition of url and credentials, calling connector object which handle connectivity to API,
    loading JSON data and pushing those to firewall..
    """
    
    # test fw
    url= 'https://10.120.1.112/gaia_api/'
    
    # credentials
    payload_list_common= {
	"user":"admin",
	"password":"checkpoint123"
    }
   
    # create connector instance
    connect = Connector(url, payload_list_common)
    
    # load JSON data into dics for pushing
    with open('data.json') as f:
        data = json.load(f)
        # call push method to add data to firewall
        push_data(data,connect)
    
    # show firewall data
    show_data(connect)
    
    #logout
    connect.logout()
    
    
if __name__ == "__main__":
    main()